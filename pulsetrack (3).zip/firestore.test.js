const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write config or sessions", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const past = new Date(Date.now() - 2000);

  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("config").get()
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("sessions").get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("config")
      .doc("rtdb")
      .set({
        userId: ALICE_UID,
        rtdbUrl: "https://example-default-rtdb.firebaseio.com",
        trackerId: "beacon_1",
        emitIntervalSeconds: 5,
        trailEnabled: true,
        highAccuracy: true,
        createdAt: past,
        updatedAt: past,
      })
  );
});

test("Owner can create, update, and list TrackerConfig; invalid/shadow/cross-user writes fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 10000);

  const configRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("config")
    .doc("rtdb");

  await assertSucceeds(
    configRef.set({
      userId: ALICE_UID,
      rtdbUrl: "https://gen-lang-client-0986790150-default-rtdb.firebaseio.com",
      trackerId: "pixel_beacon_01",
      emitIntervalSeconds: 5,
      trailEnabled: true,
      highAccuracy: true,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("config").get()
  );

  // Partial update on allowed keys (including viewerEmail) succeeds
  await assertSucceeds(
    configRef.update({
      emitIntervalSeconds: 2,
      highAccuracy: false,
      viewerEmail: "parent@example.com",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject oversized viewerEmail (> 254 chars)
  await assertFails(
    configRef.update({
      viewerEmail: "a".repeat(255),
      updatedAt: new Date(Date.now() - 900),
    })
  );

  // Reject mutating immutable createdAt
  await assertFails(
    configRef.update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject shadow/ghost field on create
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("config")
      .doc("rtdb_shadow")
      .set({
        userId: ALICE_UID,
        rtdbUrl: "https://example.firebaseio.com",
        trackerId: "beacon_1",
        emitIntervalSeconds: 5,
        trailEnabled: true,
        highAccuracy: true,
        isAdmin: true,
        createdAt: created,
        updatedAt: created,
      })
  );

  // Reject @DocumentId `id` field inside document body
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("config")
      .doc("rtdb_id_field")
      .set({
        id: "rtdb_id_field",
        userId: ALICE_UID,
        rtdbUrl: "https://example.firebaseio.com",
        trackerId: "beacon_1",
        emitIntervalSeconds: 5,
        trailEnabled: true,
        highAccuracy: true,
        createdAt: created,
        updatedAt: created,
      })
  );

  // Cross-user isolation: Bob cannot read or overwrite Alice's config
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("config")
      .doc("rtdb")
      .get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("config")
      .doc("rtdb")
      .update({
        trackerId: "hijacked",
        updatedAt: new Date(Date.now() - 500),
      })
  );
});

test("Owner TrackingSession lifecycle enforces ACTIVE -> STOPPED terminal lock and cross-user isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const started = new Date(Date.now() - 15000);

  const sessionRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("sessions")
    .doc("session_001");

  // Create ACTIVE session (mirrors Kotlin create payload)
  await assertSucceeds(
    sessionRef.set({
      userId: ALICE_UID,
      trackerId: "pixel_beacon_01",
      status: "ACTIVE",
      pointsEmitted: 0,
      distanceMeters: 0.0,
      startedAt: started,
      updatedAt: started,
    })
  );

  // Incremental telemetry update while ACTIVE
  await assertSucceeds(
    sessionRef.update({
      pointsEmitted: 12,
      distanceMeters: 145.6,
      lastLatitude: 37.7749,
      lastLongitude: -122.4194,
      updatedAt: new Date(Date.now() - 5000),
    })
  );

  // Transition ACTIVE -> STOPPED with endedAt
  const ended = new Date(Date.now() - 2000);
  await assertSucceeds(
    sessionRef.update({
      status: "STOPPED",
      pointsEmitted: 18,
      distanceMeters: 210.4,
      lastLatitude: 37.7755,
      lastLongitude: -122.4189,
      updatedAt: ended,
      endedAt: ended,
    })
  );

  // Terminal state lock: STOPPED session cannot be updated again
  await assertFails(
    sessionRef.update({
      status: "ACTIVE",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject future timestamp (> request.time)
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("sessions")
      .doc("session_future")
      .set({
        userId: ALICE_UID,
        trackerId: "pixel_beacon_01",
        status: "ACTIVE",
        pointsEmitted: 0,
        distanceMeters: 0.0,
        startedAt: new Date(Date.now() + 60000),
        updatedAt: new Date(Date.now() + 60000),
      })
  );

  // Bob cannot list or delete Alice's sessions
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("sessions").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("sessions")
      .doc("session_001")
      .delete()
  );
});
