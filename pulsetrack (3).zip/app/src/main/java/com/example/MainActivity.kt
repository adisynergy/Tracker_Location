package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.Route
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.authStateFlow
import com.example.data.local.TelemetryDatabase
import com.example.data.local.TrackingPreferencesStore
import com.example.data.model.TrackerConfig
import com.example.data.model.UiState
import com.example.data.remote.RealtimeDatabaseEmitter
import com.example.data.remote.TrackerFirestoreRepository
import com.example.location.LocationTrackingService
import com.example.ui.BeaconViewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.BeaconScreen
import com.example.ui.screens.CredentialsScreen
import com.example.ui.screens.TrailScreen
import com.example.ui.screens.checkForegroundLocation
import com.example.ui.theme.PulseTrackTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

private enum class PulseTab(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
) {
    BEACON(R.string.nav_beacon, Icons.Filled.Radar, Icons.Outlined.Radar, "nav_beacon"),
    TRAIL(R.string.nav_trail, Icons.Filled.Route, Icons.Outlined.Route, "nav_trail"),
    CREDENTIALS(R.string.nav_credentials, Icons.Filled.Key, Icons.Outlined.Key, "nav_credentials")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PulseTrackTheme {
                PulseTrackApp()
            }
        }
    }
}

@Composable
fun PulseTrackApp() {
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = { /* AuthStateListener updates currentUser automatically */ })
    } else {
        key(user.uid) {
            AuthenticatedShell(currentUserId = user.uid)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedShell(currentUserId: String) {
    val viewModel: BeaconViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                val dao = TelemetryDatabase.getInstance(app).telemetryDao()
                val prefsStore = TrackingPreferencesStore(app)
                BeaconViewModel(
                    firestoreRepository = TrackerFirestoreRepository(db),
                    telemetryDao = dao,
                    prefsStore = prefsStore,
                    rtdbEmitter = RealtimeDatabaseEmitter(),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val context = androidx.compose.ui.platform.LocalContext.current
    val isAlwaysOnArmed by viewModel.isAlwaysOnArmed.collectAsStateWithLifecycle()
    val runtime by viewModel.runtimeState.collectAsStateWithLifecycle()
    val configState by viewModel.configState.collectAsStateWithLifecycle()

    LaunchedEffect(isAlwaysOnArmed, configState) {
        if (isAlwaysOnArmed && !runtime.isTracking && checkForegroundLocation(context)) {
            val cfg = (configState as? UiState.Success)?.data ?: TrackerConfig(userId = currentUserId)
            LocationTrackingService.startTracking(context, cfg)
        }
    }

    var selectedTab by rememberSaveable { mutableStateOf(PulseTab.BEACON) }
    val snackbarHostState = remember { SnackbarHostState() }
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    LaunchedEffect(statusBanner) {
        val msg = statusBanner
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    if (selectedTab != PulseTab.BEACON) {
        BackHandler {
            selectedTab = PulseTab.BEACON
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleLarge
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            },
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        PulseTab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            val label = stringResource(tab.labelRes)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        PulseTab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            val label = stringResource(tab.labelRes)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (selectedTab) {
                        PulseTab.BEACON -> BeaconScreen(
                            viewModel = viewModel,
                            currentUserId = currentUserId,
                            onOpenCredentials = { selectedTab = PulseTab.CREDENTIALS }
                        )

                        PulseTab.TRAIL -> TrailScreen(
                            viewModel = viewModel,
                            currentUserId = currentUserId
                        )

                        PulseTab.CREDENTIALS -> CredentialsScreen(
                            viewModel = viewModel,
                            currentUserId = currentUserId
                        )
                    }
                }
            }
        }
    }
}
