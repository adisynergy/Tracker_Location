package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.auth.signOut
import com.example.data.model.TrackerConfig
import com.example.data.model.UiState
import com.example.ui.BeaconViewModel
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

@Composable
fun CredentialsScreen(
    viewModel: BeaconViewModel,
    currentUserId: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val configState by viewModel.configState.collectAsStateWithLifecycle()
    val isTesting by viewModel.isTestingConnection.collectAsStateWithLifecycle()
    val isSaving by viewModel.isSavingConfig.collectAsStateWithLifecycle()

    val currentConfig = when (val cfg = configState) {
        is UiState.Success -> cfg.data
        else -> TrackerConfig(userId = currentUserId)
    }

    var rtdbUrlInput by remember(currentConfig.rtdbUrl) { mutableStateOf(currentConfig.rtdbUrl) }
    var trackerIdInput by remember(currentConfig.trackerId) { mutableStateOf(currentConfig.trackerId) }
    var viewerEmailInput by remember(currentConfig.viewerEmail) { mutableStateOf(currentConfig.viewerEmail) }
    var trailEnabledInput by remember(currentConfig.trailEnabled) { mutableStateOf(currentConfig.trailEnabled) }
    var rulesCopied by remember { mutableStateOf(false) }
    val rtdbRulesSnippet = remember(context) {
        context.resources.openRawResource(R.raw.rtdb_rules).bufferedReader().use { it.readText().trim() }
    }

    LaunchedEffect(currentConfig) {
        rtdbUrlInput = currentConfig.rtdbUrl
        trackerIdInput = currentConfig.trackerId
        viewerEmailInput = currentConfig.viewerEmail
        trailEnabledInput = currentConfig.trailEnabled
    }

    val userEmail = Firebase.auth.currentUser?.email ?: "Signed-in Google User"
    val hasFg = checkForegroundLocation(context)
    val hasBg = checkBackgroundLocation(context)
    val hasNotif = checkNotificationPermission(context)
    val hasUnrestrictedBattery = checkBatteryUnrestricted(context)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxWidth()
        ) {
            // Header Banner + Signed-In Account
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(132.dp)
                    .clip(MaterialTheme.shapes.large)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_telemetry_header_1795505190818),
                    contentDescription = "Firebase Realtime Database telemetry setup banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Transparent,
                                    MaterialTheme.colorScheme.background.copy(alpha = 0.92f)
                                )
                            )
                        )
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = userEmail,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "UID: $currentUserId",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            signOut(
                                context = context,
                                credentialManager = credentialManager,
                                scope = scope
                            )
                        },
                        modifier = Modifier.testTag("sign_out_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.sign_out))
                    }
                }
            }

            // What Credentials Are Needed Card
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = MaterialTheme.shapes.medium,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Key,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Credentials Checklist",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    CredentialChecklistItem(
                        done = true,
                        title = "1. Firebase Project & google-services.json",
                        detail = "Provisioned automatically (gen-lang-client-0986790150) with debug SHA-1/SHA-256 registered."
                    )
                    CredentialChecklistItem(
                        done = true,
                        title = "2. Google Sign-In Auth Token",
                        detail = "Authenticated via Jetpack Credential Manager so RTDB writes carry your Firebase Auth token automatically—no database secret needed."
                    )
                    CredentialChecklistItem(
                        done = false,
                        title = "3. Enable Realtime Database in Firebase Console",
                        detail = "Open Firebase Console -> Build -> Realtime Database -> Create Database for project gen-lang-client-0986790150, then verify the URL and paste the rules below."
                    )
                }
            }

            // RTDB Target Configuration Form
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = MaterialTheme.shapes.medium,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Realtime Database Target",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    OutlinedTextField(
                        value = rtdbUrlInput,
                        onValueChange = { rtdbUrlInput = it },
                        label = { Text("Firebase Realtime Database URL") },
                        placeholder = { Text(TrackerConfig.DEFAULT_RTDB_URL) },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rtdb_url_input")
                    )

                    OutlinedTextField(
                        value = trackerIdInput,
                        onValueChange = { trackerIdInput = it },
                        label = { Text("Tracker / Device ID") },
                        supportingText = { Text("Letters, numbers, underscores, or hyphens (1–64 chars)") },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tracker_id_input")
                    )

                    OutlinedTextField(
                        value = viewerEmailInput,
                        onValueChange = { viewerEmailInput = it },
                        label = { Text("Authorized Parent / Viewer Email (Optional)") },
                        placeholder = { Text("parent@gmail.com") },
                        supportingText = {
                            Text("Leave blank for same-account viewing, or enter a different parent Google email allowed to map this phone.")
                        },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("viewer_email_input")
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Append Breadcrumb Trail (/trail)",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Writes historical points in addition to /current",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = trailEnabledInput,
                            onCheckedChange = { trailEnabledInput = it },
                            modifier = Modifier.testTag("trail_enabled_switch")
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                viewModel.saveConfig(
                                    rtdbUrl = rtdbUrlInput,
                                    trackerId = trackerIdInput,
                                    emitIntervalSeconds = currentConfig.emitIntervalSeconds,
                                    trailEnabled = trailEnabledInput,
                                    highAccuracy = currentConfig.highAccuracy,
                                    viewerEmail = viewerEmailInput
                                )
                            },
                            enabled = !isSaving,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("save_config_button")
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save")
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.testRtdbConnection(
                                    rtdbUrl = rtdbUrlInput,
                                    trackerId = trackerIdInput
                                )
                            },
                            enabled = !isTesting,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("test_rtdb_button")
                        ) {
                            if (isTesting) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Filled.Science, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Test RTDB")
                            }
                        }
                    }
                }
            }

            // Copyable RTDB Rules Card
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = MaterialTheme.shapes.medium,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Realtime Database Rules",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(
                            onClick = {
                                copyToClipboard(context, "RTDB Rules", rtdbRulesSnippet)
                                rulesCopied = true
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("copy_rtdb_rules_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = "Copy Realtime Database rules",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = rtdbRulesSnippet,
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                    if (rulesCopied) {
                        Text(
                            text = "Copied rules to clipboard—paste in Firebase Console -> Realtime Database -> Rules.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            // Permission Health Diagnostics
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = MaterialTheme.shapes.medium,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Device Permissions",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        OutlinedButton(
                            onClick = { openAppSettings(context) },
                            modifier = Modifier.testTag("credentials_open_settings_button")
                        ) {
                            Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("App Settings")
                        }
                    }

                    PermissionStatusRow("Foreground GPS (Fine / Coarse)", hasFg)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        PermissionStatusRow("Background GPS (Allow all the time)", hasBg)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        PermissionStatusRow("Persistent Beacon Notification", hasNotif)
                    }
                    PermissionStatusRow("Unrestricted Battery (Doze Exempt)", hasUnrestrictedBattery)
                }
            }
        }
    }
}

@Composable
private fun CredentialChecklistItem(
    done: Boolean,
    title: String,
    detail: String
) {
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = if (done) Icons.Filled.CheckCircle else Icons.Filled.WarningAmber,
            contentDescription = null,
            tint = if (done) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.tertiary,
            modifier = Modifier
                .padding(top = 2.dp)
                .size(18.dp)
        )
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = detail,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PermissionStatusRow(label: String, granted: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = if (granted) "GRANTED" else "MISSING",
            style = MaterialTheme.typography.labelSmall,
            color = if (granted) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.tertiary
        )
    }
}
