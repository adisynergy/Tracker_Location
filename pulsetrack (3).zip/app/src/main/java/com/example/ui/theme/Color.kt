package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Telemetry Palette (Dark-first Precision Cartography)
val ObsidianBg = Color(0xFF070D17)
val MidnightSurface = Color(0xFF0E1726)
val SlateSurfaceVariant = Color(0xFF162338)
val ElevatedCardSurface = Color(0xFF1B2B44)

val CyanPulse = Color(0xFF22D3EE)
val CyanPulseDark = Color(0xFF0891B2)
val EmeraldLive = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF064E3B)
val AmberWarn = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF451A03)
val CoralAlert = Color(0xFFF43F5E)
val CoralContainer = Color(0xFF4C0519)

val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val OutlineSubtleDark = Color(0xFF263854)

// Light Theme Counterparts
val CloudBg = Color(0xFFF4F8FC)
val CrispSurface = Color(0xFFFFFFFF)
val SoftSlateVariant = Color(0xFFE6EEF8)
val DeepCyan = Color(0xFF0E7490)
val DeepEmerald = Color(0xFF047857)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val OutlineSubtleLight = Color(0xFFCBD5E1)
