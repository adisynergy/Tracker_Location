package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.AltRoute
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.TrackerConfig
import com.example.data.model.UiState
import com.example.location.LocationTrackingService
import com.example.ui.BeaconViewModel
import com.example.ui.components.MetricReadoutCard
import com.example.ui.components.RadarBeaconCanvas
import com.example.ui.components.StatusPill
import com.example.ui.components.formatClockTime
import com.example.ui.components.formatDistance
import com.example.ui.theme.JetBrainsMonoFontFamily
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BeaconScreen(
    viewModel: BeaconViewModel,
    currentUserId: String,
    onOpenCredentials: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val runtime by viewModel.runtimeState.collectAsStateWithLifecycle()
    val isAlwaysOnArmed by viewModel.isAlwaysOnArmed.collectAsStateWithLifecycle()
    val configState by viewModel.configState.collectAsStateWithLifecycle()
    val pendingCount by viewModel.pendingCount.collectAsStateWithLifecycle()
    val syncedCount by viewModel.syncedCount.collectAsStateWithLifecycle()

    val activeConfig = when (val cfg = configState) {
        is UiState.Success -> cfg.data
        else -> TrackerConfig(userId = currentUserId)
    }

    var hasForegroundLoc by remember { mutableStateOf(checkForegroundLocation(context)) }
    var hasBackgroundLoc by remember { mutableStateOf(checkBackgroundLocation(context)) }
    var hasNotificationPerm by remember { mutableStateOf(checkNotificationPermission(context)) }
    var isBatteryUnrestricted by remember { mutableStateOf(checkBatteryUnrestricted(context)) }
    var pendingActionAfterPerm by remember { mutableStateOf<(() -> Unit)?>(null) }
    var copiedMessage by remember { mutableStateOf<String?>(null) }

    val backgroundPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasBackgroundLoc = granted || checkBackgroundLocation(context)
    }

    val foregroundAndNotifLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        hasForegroundLoc = checkForegroundLocation(context)
        hasNotificationPerm = checkNotificationPermission(context)
        if (hasForegroundLoc) {
            pendingActionAfterPerm?.invoke()
        }
        pendingActionAfterPerm = null
    }

    fun ensureForegroundPermissionsAndRun(action: () -> Unit) {
        hasForegroundLoc = checkForegroundLocation(context)
        hasNotificationPerm = checkNotificationPermission(context)
        if (hasForegroundLoc) {
            action()
            return
        }
        pendingActionAfterPerm = action
        val perms = buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
        foregroundAndNotifLauncher.launch(perms)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxWidth()
        ) {
            // Top Status Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                val (pillText, pillColor) = when {
                    runtime.isTracking && runtime.rtdbConnected ->
                        "STREAMING LIVE" to MaterialTheme.colorScheme.secondary
                    runtime.isTracking ->
                        "TRACKING • RTDB PENDING" to MaterialTheme.colorScheme.tertiary
                    else ->
                        "STANDBY" to MaterialTheme.colorScheme.primary
                }
                StatusPill(
                    text = pillText,
                    accentColor = pillColor,
                    isPulsing = runtime.isTracking
                )

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = activeConfig.trackerId,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Hero Coordinate Card with Radar Canvas
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = MaterialTheme.shapes.large,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)),
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.padding(18.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadarBeaconCanvas(
                            isTracking = runtime.isTracking,
                            bearingDegrees = runtime.lastFix?.bearingDegrees ?: 0f,
                            accuracyMeters = runtime.lastFix?.accuracyMeters ?: 12f,
                            hasFix = runtime.lastFix != null,
                            modifier = Modifier.size(104.dp)
                        )

                        Column(
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "LIVE COORDINATES",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (runtime.lastFix != null) {
                                    IconButton(
                                        onClick = {
                                            val fix = runtime.lastFix ?: return@IconButton
                                            val text = String.format(
                                                Locale.US,
                                                "%.6f, %.6f",
                                                fix.latitude,
                                                fix.longitude
                                            )
                                            copyToClipboard(context, "Coordinates", text)
                                            copiedMessage = "Copied $text"
                                        },
                                        modifier = Modifier
                                            .size(48.dp)
                                            .testTag("copy_coords_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.ContentCopy,
                                            contentDescription = "Copy coordinates",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            val fix = runtime.lastFix
                            Text(
                                text = if (fix != null) {
                                    String.format(Locale.US, "%.6f", fix.latitude)
                                } else {
                                    "--.------"
                                },
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (fix != null) {
                                    String.format(Locale.US, "%.6f", fix.longitude)
                                } else {
                                    "---.------"
                                },
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Text(
                                text = if (fix != null) {
                                    "Updated ${formatClockTime(fix.recordedAtMs)} • ${fix.provider.uppercase(Locale.US)}"
                                } else {
                                    "Tap Start Tracking to stream GPS fixes"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (copiedMessage != null) {
                        Text(
                            text = copiedMessage.orEmpty(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    // Primary Start / Stop CTA + Manual Ping
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                if (runtime.isTracking) {
                                    LocationTrackingService.stopTracking(context)
                                } else {
                                    ensureForegroundPermissionsAndRun {
                                        LocationTrackingService.startTracking(context, activeConfig)
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (runtime.isTracking) {
                                    MaterialTheme.colorScheme.error
                                } else {
                                    MaterialTheme.colorScheme.secondary
                                },
                                contentColor = if (runtime.isTracking) {
                                    MaterialTheme.colorScheme.onError
                                } else {
                                    MaterialTheme.colorScheme.onSecondary
                                }
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("toggle_tracking_button")
                        ) {
                            Icon(
                                imageVector = if (runtime.isTracking) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(
                                    if (runtime.isTracking) R.string.stop_broadcast else R.string.start_broadcast
                                ),
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                ensureForegroundPermissionsAndRun {
                                    LocationTrackingService.pingOnce(context, activeConfig)
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(52.dp)
                                .testTag("ping_now_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MyLocation,
                                contentDescription = stringResource(R.string.ping_now),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // Always-on Background Location Prompt Card (Play Policy Compliant: after foreground or explicit)
            AnimatedVisibility(visible = !hasBackgroundLoc && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                    shape = MaterialTheme.shapes.medium,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.NotificationsActive,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = stringResource(R.string.background_rationale_title),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = stringResource(R.string.background_rationale_body),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    if (!hasForegroundLoc) {
                                        ensureForegroundPermissionsAndRun {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                backgroundPermLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                                            }
                                        }
                                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        backgroundPermLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                                    }
                                },
                                modifier = Modifier.testTag("grant_background_location_button")
                            ) {
                                Text("Enable Allow All The Time")
                            }
                            OutlinedButton(
                                onClick = { openAppSettings(context) },
                                modifier = Modifier.testTag("open_location_settings_button")
                            ) {
                                Text("Settings")
                            }
                        }
                    }
                }
            }

            // Always-On Persistence & Battery Exemption Card
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = MaterialTheme.shapes.medium,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Always-On Auto-Resume",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isAlwaysOnArmed) "ARMED" else "OFF",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isAlwaysOnArmed) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = if (isAlwaysOnArmed) {
                            "Once started, PulseTrack stays active across app close and auto-resumes on device reboot until you tap Stop."
                        } else {
                            "Tap Start Continuous Tracking once to arm automatic resume across app restarts and device reboots."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!isBatteryUnrestricted) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Battery: Optimized (may throttle)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedButton(
                                onClick = {
                                    openBatteryOptimizationSettings(context)
                                    isBatteryUnrestricted = checkBatteryUnrestricted(context)
                                },
                                modifier = Modifier.testTag("unrestricted_battery_button")
                            ) {
                                Text("Set Unrestricted")
                            }
                        }
                    }
                }
            }

            // Telemetry Metrics Grid (2x2)
            val fix = runtime.lastFix
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                MetricReadoutCard(
                    label = "Accuracy",
                    value = if (fix != null) String.format(Locale.US, "±%.1f", fix.accuracyMeters) else "--",
                    unit = "m",
                    icon = Icons.Filled.GpsFixed,
                    modifier = Modifier.weight(1f)
                )
                MetricReadoutCard(
                    label = "Speed",
                    value = if (fix != null) String.format(Locale.US, "%.1f", fix.speedMps * 3.6f) else "--",
                    unit = "km/h",
                    icon = Icons.Filled.Speed,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                MetricReadoutCard(
                    label = "Altitude",
                    value = if (fix != null) String.format(Locale.US, "%.0f", fix.altitudeMeters) else "--",
                    unit = "m",
                    icon = Icons.Filled.Terrain,
                    modifier = Modifier.weight(1f)
                )
                MetricReadoutCard(
                    label = "Session Dist.",
                    value = formatDistance(runtime.sessionDistanceMeters),
                    unit = "${runtime.sessionPointsCount} pts",
                    icon = Icons.AutoMirrored.Filled.AltRoute,
                    modifier = Modifier.weight(1f)
                )
            }

            // Emit Cadence & Accuracy Controls
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = MaterialTheme.shapes.medium,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Emit Cadence",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(2L, 5L, 15L, 30L, 60L).forEach { sec ->
                            FilterChip(
                                selected = activeConfig.emitIntervalSeconds == sec,
                                onClick = {
                                    viewModel.updateIntervalQuick(activeConfig, sec)
                                    if (runtime.isTracking) {
                                        LocationTrackingService.startTracking(
                                            context,
                                            activeConfig.copy(emitIntervalSeconds = sec)
                                        )
                                    }
                                },
                                label = { Text("${sec}s") },
                                modifier = Modifier.testTag("interval_chip_$sec")
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Explore,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = "High-Accuracy GPS Priority",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (activeConfig.highAccuracy) "PRIORITY_HIGH_ACCURACY" else "BALANCED_POWER_ACCURACY",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = activeConfig.highAccuracy,
                            onCheckedChange = { checked ->
                                viewModel.toggleAccuracyQuick(activeConfig, checked)
                                if (runtime.isTracking) {
                                    LocationTrackingService.startTracking(
                                        context,
                                        activeConfig.copy(highAccuracy = checked)
                                    )
                                }
                            },
                            modifier = Modifier.testTag("high_accuracy_switch")
                        )
                    }
                }
            }

            // Firebase RTDB Pipeline Status Card
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = MaterialTheme.shapes.medium,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (runtime.lastRtdbError == null) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
                                contentDescription = null,
                                tint = if (runtime.lastRtdbError == null) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Firebase Realtime Database",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        OutlinedButton(
                            onClick = onOpenCredentials,
                            modifier = Modifier.testTag("open_rtdb_setup_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Settings,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Setup")
                        }
                    }

                    Text(
                        text = "${activeConfig.rtdbUrl}/live_trackers/$currentUserId/${activeConfig.trackerId}/current",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (activeConfig.viewerEmail.isNotBlank()) {
                            "Shared with viewer: ${activeConfig.viewerEmail}"
                        } else {
                            "Viewer access: Same Google account only"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (activeConfig.viewerEmail.isNotBlank()) {
                            MaterialTheme.colorScheme.secondary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Synced: $syncedCount",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "Queued: $pendingCount",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (pendingCount > 0) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (runtime.lastEmitLatencyMs != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Bolt,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "${runtime.lastEmitLatencyMs}ms",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    if (runtime.lastRtdbError != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = runtime.lastRtdbError.orEmpty(),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

fun checkForegroundLocation(context: Context): Boolean {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    return fine || coarse
}

fun checkBackgroundLocation(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
    } else {
        checkForegroundLocation(context)
    }
}

fun checkNotificationPermission(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }
}

fun checkBatteryUnrestricted(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return true
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

fun openBatteryOptimizationSettings(context: Context) {
    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    context.startActivity(intent)
}

fun openAppSettings(context: Context) {
    val intent = Intent(
        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.fromParts("package", context.packageName, null)
    )
    context.startActivity(intent)
}

fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
