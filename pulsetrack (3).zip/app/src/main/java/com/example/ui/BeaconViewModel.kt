package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.TelemetryDao
import com.example.data.local.TelemetryPointEntity
import com.example.data.local.TrackingPreferencesStore
import com.example.data.model.TrackerConfig
import com.example.data.model.TrackingSession
import com.example.data.model.UiState
import com.example.data.remote.RealtimeDatabaseEmitter
import com.example.data.remote.TrackerFirestoreRepository
import com.example.location.TrackingRuntimeState
import com.example.location.TrackingStateHolder
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BeaconViewModel(
    private val firestoreRepository: TrackerFirestoreRepository,
    private val telemetryDao: TelemetryDao,
    private val prefsStore: TrackingPreferencesStore,
    private val rtdbEmitter: RealtimeDatabaseEmitter,
    private val currentUserId: String
) : ViewModel() {

    val runtimeState: StateFlow<TrackingRuntimeState> = TrackingStateHolder.state

    val isAlwaysOnArmed: StateFlow<Boolean> = prefsStore.prefsFlow
        .map { it.wasTrackingEnabled }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = false
        )

    val configState: StateFlow<UiState<TrackerConfig>> = firestoreRepository.observeConfig(currentUserId)
        .map<TrackerConfig?, UiState<TrackerConfig>> { cfg ->
            UiState.Success(
                cfg ?: TrackerConfig(
                    userId = currentUserId,
                    rtdbUrl = TrackerConfig.DEFAULT_RTDB_URL,
                    trackerId = TrackerConfig.DEFAULT_TRACKER_ID,
                    emitIntervalSeconds = 5L,
                    trailEnabled = true,
                    highAccuracy = true
                )
            )
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing tracker config", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load configuration"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val sessionsState: StateFlow<UiState<List<TrackingSession>>> = firestoreRepository.observeSessions(currentUserId)
        .map<List<TrackingSession>, UiState<List<TrackingSession>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing sessions", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load tracking sessions"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val recentPoints: StateFlow<List<TelemetryPointEntity>> = telemetryDao.observeRecentPoints(currentUserId, limit = 120)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    val pendingCount: StateFlow<Int> = telemetryDao.observePendingCount(currentUserId)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = 0
        )

    val syncedCount: StateFlow<Int> = telemetryDao.observeSyncedCount(currentUserId)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = 0
        )

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _isTestingConnection = MutableStateFlow(false)
    val isTestingConnection: StateFlow<Boolean> = _isTestingConnection.asStateFlow()

    private val _isSavingConfig = MutableStateFlow(false)
    val isSavingConfig: StateFlow<Boolean> = _isSavingConfig.asStateFlow()

    fun saveConfig(
        rtdbUrl: String,
        trackerId: String,
        emitIntervalSeconds: Long,
        trailEnabled: Boolean,
        highAccuracy: Boolean,
        viewerEmail: String = ""
    ) {
        val cleanViewer = viewerEmail.trim().lowercase(java.util.Locale.US)
        val cleanUrl = rtdbUrl.trim().trimEnd('/')
        val cleanTrackerId = trackerId.trim().ifBlank { TrackerConfig.DEFAULT_TRACKER_ID }
        viewModelScope.launch {
            _isSavingConfig.value = true
            prefsStore.saveConfig(
                rtdbUrl = cleanUrl,
                trackerId = cleanTrackerId,
                emitIntervalSeconds = emitIntervalSeconds,
                trailEnabled = trailEnabled,
                highAccuracy = highAccuracy,
                viewerEmail = cleanViewer
            )
            val result = firestoreRepository.saveConfig(
                userId = currentUserId,
                rtdbUrl = cleanUrl,
                trackerId = cleanTrackerId,
                emitIntervalSeconds = emitIntervalSeconds,
                trailEnabled = trailEnabled,
                highAccuracy = highAccuracy,
                viewerEmail = cleanViewer
            )
            if (result.isSuccess) {
                val ownerEmail = com.google.firebase.Firebase.auth.currentUser?.email.orEmpty()
                val rtdbSync = kotlinx.coroutines.withContext(Dispatchers.IO) {
                    rtdbEmitter.syncViewerAccess(
                        rtdbUrl = cleanUrl,
                        uid = currentUserId,
                        ownerEmail = ownerEmail,
                        trackerId = cleanTrackerId,
                        viewerEmail = cleanViewer
                    )
                }
                _isSavingConfig.value = false
                TrackingStateHolder.update {
                    it.copy(
                        activeRtdbUrl = cleanUrl,
                        activeTrackerId = cleanTrackerId,
                        emitIntervalSeconds = emitIntervalSeconds
                    )
                }
                _statusBanner.value = if (rtdbSync.isSuccess) {
                    if (cleanViewer.isNotBlank()) {
                        "Saved & shared with $cleanViewer."
                    } else {
                        "Configuration saved to cloud."
                    }
                } else {
                    "Saved config, but RTDB viewer sync failed: ${rtdbSync.exceptionOrNull()?.message}"
                }
            } else {
                _isSavingConfig.value = false
                _statusBanner.value = result.exceptionOrNull()?.message ?: "Failed to save configuration."
            }
        }
    }

    fun updateIntervalQuick(currentConfig: TrackerConfig, intervalSeconds: Long) {
        saveConfig(
            rtdbUrl = currentConfig.rtdbUrl,
            trackerId = currentConfig.trackerId,
            emitIntervalSeconds = intervalSeconds,
            trailEnabled = currentConfig.trailEnabled,
            highAccuracy = currentConfig.highAccuracy,
            viewerEmail = currentConfig.viewerEmail
        )
    }

    fun toggleAccuracyQuick(currentConfig: TrackerConfig, highAccuracy: Boolean) {
        saveConfig(
            rtdbUrl = currentConfig.rtdbUrl,
            trackerId = currentConfig.trackerId,
            emitIntervalSeconds = currentConfig.emitIntervalSeconds,
            trailEnabled = currentConfig.trailEnabled,
            highAccuracy = highAccuracy,
            viewerEmail = currentConfig.viewerEmail
        )
    }

    fun testRtdbConnection(rtdbUrl: String, trackerId: String) {
        val cleanTrackerId = trackerId.trim().ifBlank { TrackerConfig.DEFAULT_TRACKER_ID }
        viewModelScope.launch(Dispatchers.IO) {
            _isTestingConnection.value = true
            val result = rtdbEmitter.testConnection(
                rtdbUrl = rtdbUrl,
                uid = currentUserId,
                trackerId = cleanTrackerId
            )
            _isTestingConnection.value = false
            result.onSuccess { latencyMs ->
                TrackingStateHolder.update {
                    it.copy(
                        lastEmitLatencyMs = latencyMs,
                        lastRtdbSuccessAtMs = System.currentTimeMillis(),
                        lastRtdbError = null,
                        rtdbConnected = true
                    )
                }
                _statusBanner.value = "RTDB connection verified in ${latencyMs}ms!"
            }.onFailure { error ->
                val msg = error.message ?: "Connection test failed."
                TrackingStateHolder.update {
                    it.copy(lastRtdbError = msg, rtdbConnected = false)
                }
                _statusBanner.value = msg
            }
        }
    }

    fun flushPendingQueue(config: TrackerConfig) {
        viewModelScope.launch(Dispatchers.IO) {
            val pending = telemetryDao.getPendingPoints(currentUserId, limit = 25)
            if (pending.isEmpty()) {
                _statusBanner.value = "All buffered points are already synced."
                return@launch
            }
            var syncedNow = 0
            for (point in pending) {
                val res = rtdbEmitter.emitCoordinate(
                    rtdbUrl = config.rtdbUrl,
                    uid = currentUserId,
                    trackerId = point.trackerId,
                    point = point,
                    trailEnabled = config.trailEnabled
                )
                res.onSuccess { latency ->
                    telemetryDao.markSynced(point.id, "${latency}ms")
                    syncedNow++
                }.onFailure { err ->
                    telemetryDao.markFailed(point.id, err.message ?: "Sync failed")
                    _statusBanner.value = "Synced $syncedNow/${pending.size}: ${err.message}"
                    return@launch
                }
            }
            _statusBanner.value = "Flushed $syncedNow queued coordinate fixes to RTDB."
        }
    }

    fun clearLocalBuffer() {
        viewModelScope.launch(Dispatchers.IO) {
            telemetryDao.clearUserPoints(currentUserId)
            _statusBanner.value = "Local coordinate buffer cleared."
        }
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    private companion object {
        const val TAG = "BeaconVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
