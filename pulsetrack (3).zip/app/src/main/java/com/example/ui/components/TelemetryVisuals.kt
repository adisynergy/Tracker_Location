package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.TelemetryPointEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

@Composable
fun RadarBeaconCanvas(
    isTracking: Boolean,
    bearingDegrees: Float,
    accuracyMeters: Float,
    hasFix: Boolean,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val outlineColor = MaterialTheme.colorScheme.outline

    val infiniteTransition = rememberInfiniteTransition(label = "radar_sweep")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep_angle"
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_scale"
    )

    Canvas(modifier = modifier) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val maxRadius = minOf(size.width, size.height) / 2f - 4.dp.toPx()

        // Concentric grid rings
        listOf(0.35f, 0.68f, 1.0f).forEach { fraction ->
            drawCircle(
                color = outlineColor.copy(alpha = 0.55f),
                radius = maxRadius * fraction,
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )
        }

        // Crosshairs
        drawLine(
            color = outlineColor.copy(alpha = 0.35f),
            start = Offset(center.x - maxRadius, center.y),
            end = Offset(center.x + maxRadius, center.y),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = outlineColor.copy(alpha = 0.35f),
            start = Offset(center.x, center.y - maxRadius),
            end = Offset(center.x, center.y + maxRadius),
            strokeWidth = 1.dp.toPx()
        )

        val activeAccent = if (isTracking) secondaryColor else primaryColor

        if (isTracking) {
            // Expanding pulse ring
            drawCircle(
                color = secondaryColor.copy(alpha = (1f - pulseScale) * 0.45f),
                radius = maxRadius * pulseScale,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Rotating radar sweep sector
            rotate(degrees = sweepAngle, pivot = center) {
                drawArc(
                    brush = Brush.sweepGradient(
                        0f to Color.Transparent,
                        0.75f to Color.Transparent,
                        1f to secondaryColor.copy(alpha = 0.38f),
                        center = center
                    ),
                    startAngle = -90f,
                    sweepAngle = 90f,
                    useCenter = true,
                    topLeft = Offset(center.x - maxRadius, center.y - maxRadius),
                    size = androidx.compose.ui.geometry.Size(maxRadius * 2f, maxRadius * 2f)
                )
            }
        }

        // Accuracy halo if fix exists
        if (hasFix) {
            val accFraction = (accuracyMeters.coerceIn(3f, 80f) / 80f).coerceIn(0.18f, 0.85f)
            drawCircle(
                color = activeAccent.copy(alpha = 0.14f),
                radius = maxRadius * accFraction,
                center = center
            )

            // Bearing indicator arrow on outer ring
            val rad = Math.toRadians((bearingDegrees - 90f).toDouble())
            val bx = center.x + (maxRadius * 0.78f * cos(rad)).toFloat()
            val by = center.y + (maxRadius * 0.78f * sin(rad)).toFloat()
            drawLine(
                color = primaryColor,
                start = center,
                end = Offset(bx, by),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawCircle(
                color = primaryColor,
                radius = 4.dp.toPx(),
                center = Offset(bx, by)
            )
        }

        // Core beacon dot
        drawCircle(
            color = activeAccent,
            radius = 7.dp.toPx(),
            center = center
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.85f),
            radius = 3.dp.toPx(),
            center = center
        )
    }
}

@Composable
fun TrailPathCanvas(
    points: List<TelemetryPointEntity>,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val outlineColor = MaterialTheme.colorScheme.outline
    val surfaceColor = MaterialTheme.colorScheme.surfaceVariant

    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(surfaceColor.copy(alpha = 0.55f))
            .border(1.dp, outlineColor.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
    ) {
        val pad = 20.dp.toPx()
        val drawW = (size.width - pad * 2f).coerceAtLeast(1f)
        val drawH = (size.height - pad * 2f).coerceAtLeast(1f)

        // Subtle grid
        val cols = 6
        val rows = 4
        for (c in 1 until cols) {
            val x = size.width * (c.toFloat() / cols)
            drawLine(outlineColor.copy(alpha = 0.25f), Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
        }
        for (r in 1 until rows) {
            val y = size.height * (r.toFloat() / rows)
            drawLine(outlineColor.copy(alpha = 0.25f), Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
        }

        if (points.isEmpty()) return@Canvas

        // Points arrive newest-first from DAO; reverse for chronological path
        val ordered = points.asReversed()
        val minLat = ordered.minOf { it.latitude }
        val maxLat = ordered.maxOf { it.latitude }
        val minLng = ordered.minOf { it.longitude }
        val maxLng = ordered.maxOf { it.longitude }
        val latSpan = max(maxLat - minLat, 0.0003)
        val lngSpan = max(maxLng - minLng, 0.0003)

        val mapped = ordered.map { pt ->
            val nx = ((pt.longitude - minLng) / lngSpan).toFloat()
            val ny = 1f - ((pt.latitude - minLat) / latSpan).toFloat()
            Offset(pad + nx * drawW, pad + ny * drawH)
        }

        if (mapped.size > 1) {
            val path = Path().apply {
                moveTo(mapped.first().x, mapped.first().y)
                for (i in 1 until mapped.size) {
                    lineTo(mapped[i].x, mapped[i].y)
                }
            }
            drawPath(
                path = path,
                brush = Brush.linearGradient(listOf(primaryColor.copy(alpha = 0.5f), secondaryColor)),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }

        // Start marker
        drawCircle(
            color = primaryColor,
            radius = 5.dp.toPx(),
            center = mapped.first()
        )

        // Latest position marker with halo
        val latest = mapped.last()
        drawCircle(
            color = secondaryColor.copy(alpha = 0.25f),
            radius = 12.dp.toPx(),
            center = latest
        )
        drawCircle(
            color = secondaryColor,
            radius = 6.dp.toPx(),
            center = latest
        )
    }
}

@Composable
fun StatusPill(
    text: String,
    accentColor: Color,
    isPulsing: Boolean = false,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "status_pill")
    val dotAlpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isPulsing) 0.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(750),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot_alpha"
    )

    Surface(
        color = accentColor.copy(alpha = 0.14f),
        shape = RoundedCornerShape(999.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.45f)),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = dotAlpha))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelMedium,
                color = accentColor,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun MetricReadoutCard(
    label: String,
    value: String,
    unit: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = MaterialTheme.shapes.medium,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        ),
        modifier = modifier
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = com.example.ui.theme.JetBrainsMonoFontFamily
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (unit.isNotBlank()) {
                    Text(
                        text = unit,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            }
        }
    }
}

fun formatDistance(meters: Double): String {
    return if (meters >= 1000.0) {
        String.format(Locale.US, "%.2f km", meters / 1000.0)
    } else {
        String.format(Locale.US, "%.0f m", meters)
    }
}

fun formatClockTime(timestampMs: Long): String {
    val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    return formatter.format(Date(timestampMs))
}
