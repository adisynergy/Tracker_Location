package com.example.location

import com.example.data.local.TelemetryPointEntity
import com.example.data.model.TrackerConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class TrackingRuntimeState(
    val isTracking: Boolean = false,
    val activeSessionId: String? = null,
    val lastFix: TelemetryPointEntity? = null,
    val sessionPointsCount: Long = 0L,
    val sessionDistanceMeters: Double = 0.0,
    val lastEmitLatencyMs: Long? = null,
    val lastRtdbSuccessAtMs: Long? = null,
    val lastRtdbError: String? = null,
    val rtdbConnected: Boolean = false,
    val activeTrackerId: String = TrackerConfig.DEFAULT_TRACKER_ID,
    val activeRtdbUrl: String = TrackerConfig.DEFAULT_RTDB_URL,
    val emitIntervalSeconds: Long = 5L
)

object TrackingStateHolder {
    private val _state = MutableStateFlow(TrackingRuntimeState())
    val state: StateFlow<TrackingRuntimeState> = _state.asStateFlow()

    fun update(transform: (TrackingRuntimeState) -> TrackingRuntimeState) {
        _state.update(transform)
    }

    fun resetSession() {
        _state.update {
            it.copy(
                isTracking = false,
                activeSessionId = null,
                sessionPointsCount = 0L,
                sessionDistanceMeters = 0.0,
                rtdbConnected = false
            )
        }
    }
}
