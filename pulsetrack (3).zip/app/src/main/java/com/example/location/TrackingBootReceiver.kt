package com.example.location

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.TrackingPreferencesStore
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TrackingBootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action !in SUPPORTED_ACTIONS) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val user = Firebase.auth.currentUser ?: return@launch
                val store = TrackingPreferencesStore(context)
                val prefs = store.readSnapshot()
                if (!prefs.wasTrackingEnabled) return@launch

                val hasForeground =
                    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (!hasForeground) return@launch

                val hasBackground = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
                } else {
                    true
                }

                if (hasBackground) {
                    try {
                        LocationTrackingService.startTracking(
                            context = context.applicationContext,
                            config = prefs.toTrackerConfig(user.uid)
                        )
                    } catch (e: Exception) {
                        Log.w(TAG, "System prevented direct FGS boot start; posting resume prompt", e)
                        showResumeNotification(context)
                    }
                } else {
                    // Android 14+ prohibits starting a location FGS from background without ACCESS_BACKGROUND_LOCATION
                    showResumeNotification(context)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showResumeNotification(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                RESUME_CHANNEL_ID,
                "Beacon Auto-Resume",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            202,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, RESUME_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("PulseTrack Beacon Ready")
            .setContentText("Tap to resume continuous tracking (grant Allow All The Time for automatic boot start).")
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        manager.notify(RESUME_NOTIFICATION_ID, notification)
    }

    companion object {
        private const val TAG = "TrackingBootReceiver"
        private const val RESUME_CHANNEL_ID = "pulsetrack_resume"
        private const val RESUME_NOTIFICATION_ID = 4042
        const val ACTION_RESTART_SERVICE = "com.example.action.RESTART_TRACKING_SERVICE"

        private val SUPPORTED_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED,
            ACTION_RESTART_SERVICE
        )
    }
}
