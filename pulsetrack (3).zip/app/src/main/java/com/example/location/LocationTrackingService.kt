package com.example.location

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.TelemetryDatabase
import com.example.data.local.TelemetryPointEntity
import com.example.data.local.TrackingPreferencesStore
import com.example.data.model.SyncStatus
import com.example.data.model.TrackerConfig
import com.example.data.remote.RealtimeDatabaseEmitter
import com.example.data.remote.TrackerFirestoreRepository
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

class LocationTrackingService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var firestoreRepository: TrackerFirestoreRepository
    private val prefsStore by lazy { TrackingPreferencesStore(applicationContext) }
    private val rtdbEmitter = RealtimeDatabaseEmitter()
    private val dao by lazy { TelemetryDatabase.getInstance(applicationContext).telemetryDao() }

    private var locationCallback: LocationCallback? = null
    private var previousLocation: Location? = null
    private var activeUserId: String = ""
    private var activeSessionId: String? = null
    private var activeRtdbUrl: String = TrackerConfig.DEFAULT_RTDB_URL
    private var activeTrackerId: String = TrackerConfig.DEFAULT_TRACKER_ID
    private var emitIntervalSeconds: Long = 5L
    private var trailEnabled: Boolean = true
    private var highAccuracy: Boolean = true
    private var activeViewerEmail: String = ""
    private var viewerSyncedForKey: String = ""
    private var pointsCount: Long = 0L
    private var totalDistanceMeters: Double = 0.0
    private var isForegroundActive: Boolean = false

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        firestoreRepository = TrackerFirestoreRepository(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                serviceScope.launch {
                    prefsStore.setTrackingEnabled(false)
                    finalizeSessionAndStop()
                }
                return START_NOT_STICKY
            }

            ACTION_PING_NOW -> {
                val uid = Firebase.auth.currentUser?.uid
                if (uid.isNullOrBlank()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                activeUserId = uid
                readExtras(intent)
                promoteToForeground("Acquiring single GPS fix...")
                requestSingleFix()
                return START_NOT_STICKY
            }

            ACTION_START -> {
                val uid = Firebase.auth.currentUser?.uid
                if (uid.isNullOrBlank()) {
                    Log.w(TAG, "Cannot start tracking service without authenticated user.")
                    TrackingStateHolder.update {
                        it.copy(isTracking = false, lastRtdbError = "Sign in with Google before starting tracking.")
                    }
                    stopSelf()
                    return START_NOT_STICKY
                }
                activeUserId = uid
                readExtras(intent)
                promoteToForeground("Initializing always-on GPS beacon...")
                serviceScope.launch {
                    prefsStore.saveConfig(
                        rtdbUrl = activeRtdbUrl,
                        trackerId = activeTrackerId,
                        emitIntervalSeconds = emitIntervalSeconds,
                        trailEnabled = trailEnabled,
                        highAccuracy = highAccuracy,
                        viewerEmail = activeViewerEmail
                    )
                    prefsStore.setTrackingEnabled(true)
                }
                startContinuousTracking()
                return START_STICKY
            }

            null -> {
                // OS restarted START_STICKY service after process eviction
                val uid = Firebase.auth.currentUser?.uid
                if (uid.isNullOrBlank()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                activeUserId = uid
                promoteToForeground("Resuming always-on GPS beacon...")
                serviceScope.launch(Dispatchers.Main) {
                    val saved = prefsStore.readSnapshot()
                    if (!saved.wasTrackingEnabled) {
                        ServiceCompat.stopForeground(this@LocationTrackingService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                        isForegroundActive = false
                        stopSelf()
                        return@launch
                    }
                    activeRtdbUrl = saved.rtdbUrl
                    activeTrackerId = saved.trackerId
                    emitIntervalSeconds = saved.emitIntervalSeconds
                    trailEnabled = saved.trailEnabled
                    highAccuracy = saved.highAccuracy
                    activeViewerEmail = saved.viewerEmail
                    TrackingStateHolder.update {
                        it.copy(
                            activeRtdbUrl = activeRtdbUrl,
                            activeTrackerId = activeTrackerId,
                            emitIntervalSeconds = emitIntervalSeconds
                        )
                    }
                    startContinuousTracking()
                }
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (!TrackingStateHolder.state.value.isTracking) return
        val restartIntent = Intent(applicationContext, TrackingBootReceiver::class.java).apply {
            action = TrackingBootReceiver.ACTION_RESTART_SERVICE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            applicationContext,
            303,
            restartIntent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        alarmManager?.set(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + 1500L,
            pendingIntent
        )
    }

    private fun readExtras(intent: Intent?) {
        intent ?: return
        activeRtdbUrl = intent.getStringExtra(EXTRA_RTDB_URL)?.trim()?.ifBlank { TrackerConfig.DEFAULT_RTDB_URL }
            ?: TrackerConfig.DEFAULT_RTDB_URL
        activeTrackerId = intent.getStringExtra(EXTRA_TRACKER_ID)?.trim()?.ifBlank { TrackerConfig.DEFAULT_TRACKER_ID }
            ?: TrackerConfig.DEFAULT_TRACKER_ID
        emitIntervalSeconds = intent.getLongExtra(EXTRA_INTERVAL_SECONDS, 5L).coerceIn(1L, 3600L)
        trailEnabled = intent.getBooleanExtra(EXTRA_TRAIL_ENABLED, true)
        highAccuracy = intent.getBooleanExtra(EXTRA_HIGH_ACCURACY, true)
        activeViewerEmail = intent.getStringExtra(EXTRA_VIEWER_EMAIL)?.trim()?.lowercase(Locale.US).orEmpty()

        TrackingStateHolder.update {
            it.copy(
                activeRtdbUrl = activeRtdbUrl,
                activeTrackerId = activeTrackerId,
                emitIntervalSeconds = emitIntervalSeconds
            )
        }
    }

    private fun promoteToForeground(statusText: String) {
        val notification = buildNotification(statusText)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        isForegroundActive = true
    }

    private fun hasLocationPermission(): Boolean {
        val fine = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    private fun startContinuousTracking() {
        if (!hasLocationPermission()) {
            TrackingStateHolder.update {
                it.copy(isTracking = false, lastRtdbError = "Location permission is required.")
            }
            stopSelf()
            return
        }

        locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }

        pointsCount = 0L
        totalDistanceMeters = 0.0
        previousLocation = null

        TrackingStateHolder.update {
            it.copy(
                isTracking = true,
                sessionPointsCount = 0L,
                sessionDistanceMeters = 0.0,
                lastRtdbError = null
            )
        }

        serviceScope.launch {
            val sessionResult = firestoreRepository.startSession(activeUserId, activeTrackerId)
            sessionResult.onSuccess { sessionId ->
                activeSessionId = sessionId
                TrackingStateHolder.update { it.copy(activeSessionId = sessionId) }
            }
        }

        val intervalMs = emitIntervalSeconds * 1000L
        val priority = if (highAccuracy) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY

        val request = LocationRequest.Builder(priority, intervalMs)
            .setMinUpdateIntervalMillis(maxOf(1000L, intervalMs / 2))
            .setWaitForAccurateLocation(false)
            .build()

        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                for (location in result.locations) {
                    handleNewLocation(location)
                }
            }
        }
        locationCallback = callback

        fusedLocationClient.requestLocationUpdates(request, callback, Looper.getMainLooper())

        // Also seed with last known location immediately if available
        fusedLocationClient.lastLocation.addOnSuccessListener { last ->
            if (last != null && pointsCount == 0L) {
                handleNewLocation(last)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun requestSingleFix() {
        if (!hasLocationPermission()) {
            stopSelf()
            return
        }
        val priority = if (highAccuracy) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        fusedLocationClient.getCurrentLocation(priority, null)
            .addOnSuccessListener { location ->
                if (location != null) {
                    serviceScope.launch {
                        processAndEmitLocation(location)
                        if (!TrackingStateHolder.state.value.isTracking) {
                            stopSelf()
                        }
                    }
                } else if (!TrackingStateHolder.state.value.isTracking) {
                    stopSelf()
                }
            }
            .addOnFailureListener {
                if (!TrackingStateHolder.state.value.isTracking) {
                    stopSelf()
                }
            }
    }

    private fun handleNewLocation(location: Location) {
        serviceScope.launch {
            processAndEmitLocation(location)
        }
    }

    private suspend fun processAndEmitLocation(location: Location) {
        val uid = activeUserId.ifBlank { Firebase.auth.currentUser?.uid.orEmpty() }
        if (uid.isBlank()) return

        previousLocation?.let { prev ->
            val delta = prev.distanceTo(location).toDouble()
            if (delta in 0.5..50_000.0) {
                totalDistanceMeters += delta
            }
        }
        previousLocation = location
        pointsCount += 1L

        val entity = TelemetryPointEntity(
            userId = uid,
            trackerId = activeTrackerId,
            latitude = location.latitude,
            longitude = location.longitude,
            accuracyMeters = if (location.hasAccuracy()) location.accuracy else 0f,
            altitudeMeters = if (location.hasAltitude()) location.altitude else 0.0,
            speedMps = if (location.hasSpeed()) location.speed else 0f,
            bearingDegrees = if (location.hasBearing()) location.bearing else 0f,
            provider = location.provider ?: "fused",
            recordedAtMs = System.currentTimeMillis(),
            syncStatus = SyncStatus.PENDING.name
        )

        val insertedId = dao.insertPoint(entity)
        val savedPoint = entity.copy(id = insertedId)

        TrackingStateHolder.update {
            it.copy(
                lastFix = savedPoint,
                sessionPointsCount = pointsCount,
                sessionDistanceMeters = totalDistanceMeters
            )
        }

        val desiredSyncKey = "$uid|$activeTrackerId|$activeViewerEmail"
        if (viewerSyncedForKey != desiredSyncKey) {
            val ownerEmail = Firebase.auth.currentUser?.email.orEmpty()
            val syncRes = rtdbEmitter.syncViewerAccess(
                rtdbUrl = activeRtdbUrl,
                uid = uid,
                ownerEmail = ownerEmail,
                trackerId = activeTrackerId,
                viewerEmail = activeViewerEmail
            )
            if (syncRes.isSuccess) {
                viewerSyncedForKey = desiredSyncKey
            }
        }

        val emitResult = rtdbEmitter.emitCoordinate(
            rtdbUrl = activeRtdbUrl,
            uid = uid,
            trackerId = activeTrackerId,
            point = savedPoint,
            trailEnabled = trailEnabled
        )

        emitResult.onSuccess { latencyMs ->
            dao.markSynced(insertedId, "${latencyMs}ms")
            TrackingStateHolder.update {
                it.copy(
                    lastFix = savedPoint.copy(syncStatus = SyncStatus.SYNCED.name, syncMessage = "${latencyMs}ms"),
                    lastEmitLatencyMs = latencyMs,
                    lastRtdbSuccessAtMs = System.currentTimeMillis(),
                    lastRtdbError = null,
                    rtdbConnected = true
                )
            }
            drainPendingQueue(uid)
        }.onFailure { error ->
            if (error is CancellationException) throw error
            val msg = error.message ?: "RTDB write failed"
            dao.markFailed(insertedId, msg)
            TrackingStateHolder.update {
                it.copy(
                    lastFix = savedPoint.copy(syncStatus = SyncStatus.FAILED.name, syncMessage = msg),
                    lastRtdbError = msg,
                    rtdbConnected = false
                )
            }
        }

        val coordSummary = String.format(
            Locale.US,
            "%.5f, %.5f • ±%.0fm • %d fixes",
            location.latitude,
            location.longitude,
            entity.accuracyMeters,
            pointsCount
        )
        if (isForegroundActive) {
            updateNotification(coordSummary)
        }

        // Checkpoint Firestore session summary every 10 points to keep Firestore quota low
        val sessionId = activeSessionId
        if (sessionId != null && pointsCount % 10L == 0L) {
            firestoreRepository.updateActiveSession(
                userId = uid,
                sessionId = sessionId,
                pointsEmitted = pointsCount,
                distanceMeters = totalDistanceMeters,
                lastLatitude = location.latitude,
                lastLongitude = location.longitude
            )
        }
    }

    private suspend fun drainPendingQueue(uid: String) {
        val pending = dao.getPendingPoints(uid, limit = 10)
        for (point in pending) {
            val res = rtdbEmitter.emitCoordinate(
                rtdbUrl = activeRtdbUrl,
                uid = uid,
                trackerId = point.trackerId,
                point = point,
                trailEnabled = trailEnabled
            )
            res.onSuccess { latency ->
                dao.markSynced(point.id, "${latency}ms")
            }.onFailure {
                break
            }
        }
    }

    private suspend fun finalizeSessionAndStop() {
        locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
        locationCallback = null

        val uid = activeUserId.ifBlank { Firebase.auth.currentUser?.uid.orEmpty() }
        val sessionId = activeSessionId
        val lastFix = TrackingStateHolder.state.value.lastFix

        if (uid.isNotBlank()) {
            rtdbEmitter.markOffline(activeRtdbUrl, uid, activeTrackerId)
            if (sessionId != null) {
                firestoreRepository.stopSession(
                    userId = uid,
                    sessionId = sessionId,
                    pointsEmitted = pointsCount,
                    distanceMeters = totalDistanceMeters,
                    lastLatitude = lastFix?.latitude,
                    lastLongitude = lastFix?.longitude
                )
            }
        }

        activeSessionId = null
        TrackingStateHolder.resetSession()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        isForegroundActive = false
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, LocationTrackingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (activeViewerEmail.isNotBlank()) {
            "PulseTrack • $activeTrackerId (Shared: $activeViewerEmail)"
        } else {
            "PulseTrack • $activeTrackerId"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPendingIntent)
            .addAction(0, getString(R.string.notification_stop_action), stopPendingIntent)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateNotification(contentText: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(contentText))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "LocationTrackingService"
        private const val CHANNEL_ID = "pulsetrack_live_beacon"
        private const val NOTIFICATION_ID = 4041

        const val ACTION_START = "com.example.action.START_TRACKING"
        const val ACTION_STOP = "com.example.action.STOP_TRACKING"
        const val ACTION_PING_NOW = "com.example.action.PING_NOW"

        const val EXTRA_RTDB_URL = "extra_rtdb_url"
        const val EXTRA_TRACKER_ID = "extra_tracker_id"
        const val EXTRA_INTERVAL_SECONDS = "extra_interval_seconds"
        const val EXTRA_TRAIL_ENABLED = "extra_trail_enabled"
        const val EXTRA_HIGH_ACCURACY = "extra_high_accuracy"
        const val EXTRA_VIEWER_EMAIL = "extra_viewer_email"

        fun startTracking(context: Context, config: TrackerConfig) {
            val intent = Intent(context, LocationTrackingService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RTDB_URL, config.rtdbUrl)
                putExtra(EXTRA_TRACKER_ID, config.trackerId)
                putExtra(EXTRA_INTERVAL_SECONDS, config.emitIntervalSeconds)
                putExtra(EXTRA_TRAIL_ENABLED, config.trailEnabled)
                putExtra(EXTRA_HIGH_ACCURACY, config.highAccuracy)
                putExtra(EXTRA_VIEWER_EMAIL, config.viewerEmail)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stopTracking(context: Context) {
            val intent = Intent(context, LocationTrackingService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun pingOnce(context: Context, config: TrackerConfig) {
            val intent = Intent(context, LocationTrackingService::class.java).apply {
                action = ACTION_PING_NOW
                putExtra(EXTRA_RTDB_URL, config.rtdbUrl)
                putExtra(EXTRA_TRACKER_ID, config.trackerId)
                putExtra(EXTRA_INTERVAL_SECONDS, config.emitIntervalSeconds)
                putExtra(EXTRA_TRAIL_ENABLED, config.trailEnabled)
                putExtra(EXTRA_HIGH_ACCURACY, config.highAccuracy)
                putExtra(EXTRA_VIEWER_EMAIL, config.viewerEmail)
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
