package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.SessionStatus
import com.example.data.model.TrackerConfig
import com.example.data.model.TrackingSession
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class TrackerFirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val trackerIdRegex = Regex("^[a-zA-Z0-9_\\-]+$")
    private val emailRegex = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")

    private fun requireUserId(expectedUserId: String? = null): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        if (expectedUserId != null) {
            check(uid == expectedUserId) { "Signed-in user changed; refusing cross-user access." }
        }
        return uid
    }

    fun observeConfig(userId: String): Flow<TrackerConfig?> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/config/${TrackerConfig.DEFAULT_CONFIG_DOC_ID}"
        emitAll(
            db.collection("users").document(uid)
                .collection("config").document(TrackerConfig.DEFAULT_CONFIG_DOC_ID)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            TrackerConfig::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else {
                        null
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveConfig(
        userId: String,
        rtdbUrl: String,
        trackerId: String,
        emitIntervalSeconds: Long,
        trailEnabled: Boolean,
        highAccuracy: Boolean,
        viewerEmail: String = ""
    ): Result<Unit> {
        val cleanUrl = rtdbUrl.trim().trimEnd('/')
        val cleanTrackerId = trackerId.trim()
        val cleanViewerEmail = viewerEmail.trim().lowercase(java.util.Locale.US)
        var docPath = "users/$userId/config/${TrackerConfig.DEFAULT_CONFIG_DOC_ID}"
        return try {
            val uid = requireUserId(userId)
            require(cleanUrl.length <= 300) { "Database URL must be 300 characters or less." }
            require(cleanTrackerId.isNotEmpty() && cleanTrackerId.length <= 64 && trackerIdRegex.matches(cleanTrackerId)) {
                "Tracker ID must be 1–64 alphanumeric, underscore, or hyphen characters."
            }
            require(emitIntervalSeconds in 1L..3600L) {
                "Emit interval must be between 1 and 3600 seconds."
            }
            require(cleanViewerEmail.length <= 254 && (cleanViewerEmail.isEmpty() || emailRegex.matches(cleanViewerEmail))) {
                "Enter a valid Authorized Viewer Google email address (or leave blank)."
            }

            val docRef = db.collection("users").document(uid)
                .collection("config").document(TrackerConfig.DEFAULT_CONFIG_DOC_ID)
            docPath = docRef.path

            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(
                    mapOf(
                        "rtdbUrl" to cleanUrl,
                        "trackerId" to cleanTrackerId,
                        "emitIntervalSeconds" to emitIntervalSeconds,
                        "trailEnabled" to trailEnabled,
                        "highAccuracy" to highAccuracy,
                        "viewerEmail" to cleanViewerEmail,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "rtdbUrl" to cleanUrl,
                        "trackerId" to cleanTrackerId,
                        "emitIntervalSeconds" to emitIntervalSeconds,
                        "trailEnabled" to trailEnabled,
                        "highAccuracy" to highAccuracy,
                        "viewerEmail" to cleanViewerEmail,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    fun observeSessions(userId: String): Flow<List<TrackingSession>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/sessions"
        emitAll(
            db.collection("users").document(uid)
                .collection("sessions")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        TrackingSession::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.startedAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun startSession(userId: String, trackerId: String): Result<String> {
        val cleanTrackerId = trackerId.trim().ifBlank { TrackerConfig.DEFAULT_TRACKER_ID }
        val sessionId = "ses_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}"
        var docPath = "users/$userId/sessions/$sessionId"
        return try {
            val uid = requireUserId(userId)
            require(cleanTrackerId.length <= 64 && trackerIdRegex.matches(cleanTrackerId)) {
                "Invalid Tracker ID format."
            }
            val docRef = db.collection("users").document(uid)
                .collection("sessions").document(sessionId)
            docPath = docRef.path

            docRef.set(
                mapOf(
                    "userId" to uid,
                    "trackerId" to cleanTrackerId,
                    "status" to SessionStatus.ACTIVE.name,
                    "pointsEmitted" to 0L,
                    "distanceMeters" to 0.0,
                    "startedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(sessionId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateActiveSession(
        userId: String,
        sessionId: String,
        pointsEmitted: Long,
        distanceMeters: Double,
        lastLatitude: Double?,
        lastLongitude: Double?
    ): Result<Unit> {
        var docPath = "users/$userId/sessions/$sessionId"
        return try {
            val uid = requireUserId(userId)
            require(sessionId.isNotBlank()) { "Session ID must not be blank." }
            val docRef = db.collection("users").document(uid)
                .collection("sessions").document(sessionId)
            docPath = docRef.path

            val payload = buildMap<String, Any> {
                put("pointsEmitted", pointsEmitted.coerceIn(0L, 10_000_000L))
                put("distanceMeters", distanceMeters.coerceIn(0.0, 100_000_000.0))
                if (lastLatitude != null && lastLatitude in -90.0..90.0) {
                    put("lastLatitude", lastLatitude)
                }
                if (lastLongitude != null && lastLongitude in -180.0..180.0) {
                    put("lastLongitude", lastLongitude)
                }
                put("updatedAt", FieldValue.serverTimestamp())
            }

            docRef.update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun stopSession(
        userId: String,
        sessionId: String,
        pointsEmitted: Long,
        distanceMeters: Double,
        lastLatitude: Double?,
        lastLongitude: Double?
    ): Result<Unit> {
        var docPath = "users/$userId/sessions/$sessionId"
        return try {
            val uid = requireUserId(userId)
            require(sessionId.isNotBlank()) { "Session ID must not be blank." }
            val docRef = db.collection("users").document(uid)
                .collection("sessions").document(sessionId)
            docPath = docRef.path

            val payload = buildMap<String, Any> {
                put("status", SessionStatus.STOPPED.name)
                put("pointsEmitted", pointsEmitted.coerceIn(0L, 10_000_000L))
                put("distanceMeters", distanceMeters.coerceIn(0.0, 100_000_000.0))
                if (lastLatitude != null && lastLatitude in -90.0..90.0) {
                    put("lastLatitude", lastLatitude)
                }
                if (lastLongitude != null && lastLongitude in -180.0..180.0) {
                    put("lastLongitude", lastLongitude)
                }
                put("updatedAt", FieldValue.serverTimestamp())
                put("endedAt", FieldValue.serverTimestamp())
            }

            docRef.update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }
}
