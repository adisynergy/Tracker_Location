package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.TrackerConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.trackingDataStore by preferencesDataStore(name = "pulsetrack_prefs")

data class PersistedTrackingPrefs(
    val wasTrackingEnabled: Boolean = false,
    val rtdbUrl: String = TrackerConfig.DEFAULT_RTDB_URL,
    val trackerId: String = TrackerConfig.DEFAULT_TRACKER_ID,
    val emitIntervalSeconds: Long = 5L,
    val trailEnabled: Boolean = true,
    val highAccuracy: Boolean = true,
    val viewerEmail: String = ""
) {
    fun toTrackerConfig(userId: String): TrackerConfig = TrackerConfig(
        userId = userId,
        rtdbUrl = rtdbUrl,
        trackerId = trackerId,
        emitIntervalSeconds = emitIntervalSeconds,
        trailEnabled = trailEnabled,
        highAccuracy = highAccuracy,
        viewerEmail = viewerEmail
    )
}

class TrackingPreferencesStore(context: Context) {
    private val appContext = context.applicationContext

    private object Keys {
        val WAS_TRACKING_ENABLED = booleanPreferencesKey("was_tracking_enabled")
        val RTDB_URL = stringPreferencesKey("rtdb_url")
        val TRACKER_ID = stringPreferencesKey("tracker_id")
        val EMIT_INTERVAL_SECONDS = longPreferencesKey("emit_interval_seconds")
        val TRAIL_ENABLED = booleanPreferencesKey("trail_enabled")
        val HIGH_ACCURACY = booleanPreferencesKey("high_accuracy")
        val VIEWER_EMAIL = stringPreferencesKey("viewer_email")
    }

    val prefsFlow: Flow<PersistedTrackingPrefs> = appContext.trackingDataStore.data.map { prefs ->
        PersistedTrackingPrefs(
            wasTrackingEnabled = prefs[Keys.WAS_TRACKING_ENABLED] ?: false,
            rtdbUrl = prefs[Keys.RTDB_URL] ?: TrackerConfig.DEFAULT_RTDB_URL,
            trackerId = prefs[Keys.TRACKER_ID] ?: TrackerConfig.DEFAULT_TRACKER_ID,
            emitIntervalSeconds = (prefs[Keys.EMIT_INTERVAL_SECONDS] ?: 5L).coerceIn(1L, 3600L),
            trailEnabled = prefs[Keys.TRAIL_ENABLED] ?: true,
            highAccuracy = prefs[Keys.HIGH_ACCURACY] ?: true,
            viewerEmail = prefs[Keys.VIEWER_EMAIL] ?: ""
        )
    }

    suspend fun readSnapshot(): PersistedTrackingPrefs = prefsFlow.first()

    suspend fun setTrackingEnabled(enabled: Boolean) {
        appContext.trackingDataStore.edit { prefs ->
            prefs[Keys.WAS_TRACKING_ENABLED] = enabled
        }
    }

    suspend fun saveConfig(
        rtdbUrl: String,
        trackerId: String,
        emitIntervalSeconds: Long,
        trailEnabled: Boolean,
        highAccuracy: Boolean,
        viewerEmail: String = ""
    ) {
        appContext.trackingDataStore.edit { prefs ->
            prefs[Keys.RTDB_URL] = rtdbUrl.trim().trimEnd('/').ifBlank { TrackerConfig.DEFAULT_RTDB_URL }
            prefs[Keys.TRACKER_ID] = trackerId.trim().ifBlank { TrackerConfig.DEFAULT_TRACKER_ID }
            prefs[Keys.EMIT_INTERVAL_SECONDS] = emitIntervalSeconds.coerceIn(1L, 3600L)
            prefs[Keys.TRAIL_ENABLED] = trailEnabled
            prefs[Keys.HIGH_ACCURACY] = highAccuracy
            prefs[Keys.VIEWER_EMAIL] = viewerEmail.trim().lowercase(java.util.Locale.US)
        }
    }
}
