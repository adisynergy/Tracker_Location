package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class TrackerConfig(
    @DocumentId val id: String = "",
    val userId: String = "",
    val rtdbUrl: String = DEFAULT_RTDB_URL,
    val trackerId: String = DEFAULT_TRACKER_ID,
    val emitIntervalSeconds: Long = 5L,
    val trailEnabled: Boolean = true,
    val highAccuracy: Boolean = true,
    val viewerEmail: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    companion object {
        const val DEFAULT_CONFIG_DOC_ID = "rtdb"
        const val DEFAULT_RTDB_URL = "https://gen-lang-client-0986790150-default-rtdb.firebaseio.com"
        const val DEFAULT_TRACKER_ID = "android_beacon_01"
    }
}

enum class SessionStatus {
    ACTIVE,
    STOPPED;

    companion object {
        fun fromRaw(raw: String?): SessionStatus =
            entries.firstOrNull { it.name == raw } ?: STOPPED
    }
}

@Keep
@IgnoreExtraProperties
data class TrackingSession(
    @DocumentId val id: String = "",
    val userId: String = "",
    val trackerId: String = "",
    val status: String = SessionStatus.ACTIVE.name,
    val pointsEmitted: Long = 0L,
    val distanceMeters: Double = 0.0,
    val lastLatitude: Double? = null,
    val lastLongitude: Double? = null,
    @ServerTimestamp val startedAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
    val endedAt: Timestamp? = null
)

enum class SyncStatus {
    PENDING,
    SYNCED,
    FAILED;

    companion object {
        fun fromRaw(raw: String?): SyncStatus =
            entries.firstOrNull { it.name == raw } ?: PENDING
    }
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
