package com.example.data.remote

import com.example.data.local.TelemetryPointEntity
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

class RealtimeDatabaseEmitter {

    fun validateRtdbUrl(rawUrl: String): String? {
        val trimmed = rawUrl.trim().trimEnd('/')
        if (trimmed.isBlank()) return null
        if (!trimmed.startsWith("https://")) return null
        return trimmed
    }

    suspend fun emitCoordinate(
        rtdbUrl: String,
        uid: String,
        trackerId: String,
        point: TelemetryPointEntity,
        trailEnabled: Boolean
    ): Result<Long> {
        val validUrl = validateRtdbUrl(rtdbUrl)
            ?: return Result.failure(IllegalArgumentException("Realtime Database URL is missing or invalid (must start with https://)."))

        val startMs = System.currentTimeMillis()
        return try {
            withTimeout(8_000L) {
                val database = FirebaseDatabase.getInstance(validUrl)
                val trackerRoot = database.getReference("live_trackers")
                    .child(uid)
                    .child(trackerId)

                val currentRef = trackerRoot.child("current")
                currentRef.child("online").onDisconnect().setValue(false)

                val payload = mapOf(
                    "uid" to uid,
                    "trackerId" to trackerId,
                    "latitude" to point.latitude,
                    "longitude" to point.longitude,
                    "accuracyMeters" to point.accuracyMeters.toDouble(),
                    "altitudeMeters" to point.altitudeMeters,
                    "speedMps" to point.speedMps.toDouble(),
                    "bearingDegrees" to point.bearingDegrees.toDouble(),
                    "provider" to point.provider,
                    "recordedAtMs" to point.recordedAtMs,
                    "serverTimestamp" to ServerValue.TIMESTAMP,
                    "online" to true
                )

                currentRef.setValue(payload).await()

                if (trailEnabled) {
                    val trailPoint = mapOf(
                        "latitude" to point.latitude,
                        "longitude" to point.longitude,
                        "accuracyMeters" to point.accuracyMeters.toDouble(),
                        "speedMps" to point.speedMps.toDouble(),
                        "bearingDegrees" to point.bearingDegrees.toDouble(),
                        "recordedAtMs" to point.recordedAtMs,
                        "serverTimestamp" to ServerValue.TIMESTAMP
                    )
                    trackerRoot.child("trail").push().setValue(trailPoint).await()
                }
            }
            val latencyMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
            Result.success(latencyMs)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(Exception(mapFriendlyRtdbError(e), e))
        }
    }

    suspend fun markOffline(rtdbUrl: String, uid: String, trackerId: String) {
        val validUrl = validateRtdbUrl(rtdbUrl) ?: return
        try {
            withTimeout(3_000L) {
                val database = FirebaseDatabase.getInstance(validUrl)
                database.getReference("live_trackers")
                    .child(uid)
                    .child(trackerId)
                    .child("current")
                    .child("online")
                    .setValue(false)
                    .await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Best-effort offline marker
        }
    }

    suspend fun syncViewerAccess(
        rtdbUrl: String,
        uid: String,
        ownerEmail: String,
        trackerId: String,
        viewerEmail: String
    ): Result<Unit> {
        val validUrl = validateRtdbUrl(rtdbUrl)
            ?: return Result.failure(IllegalArgumentException("Realtime Database URL is missing or invalid."))
        val normalizedViewer = viewerEmail.trim().lowercase(java.util.Locale.US)
        val linkKey = "${uid}__${trackerId}"
        return try {
            withTimeout(8_000L) {
                val database = FirebaseDatabase.getInstance(validUrl)
                val viewerRef = database.getReference("live_trackers")
                    .child(uid)
                    .child(trackerId)
                    .child("viewerEmail")
                val linkRef = database.getReference("shared_links").child(linkKey)

                if (normalizedViewer.isNotBlank()) {
                    viewerRef.setValue(normalizedViewer).await()
                    linkRef.setValue(
                        mapOf(
                            "ownerUid" to uid,
                            "ownerEmail" to ownerEmail.trim().lowercase(java.util.Locale.US),
                            "trackerId" to trackerId,
                            "viewerEmail" to normalizedViewer,
                            "updatedAt" to ServerValue.TIMESTAMP
                        )
                    ).await()
                } else {
                    viewerRef.removeValue().await()
                    linkRef.removeValue().await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(Exception(mapFriendlyRtdbError(e), e))
        }
    }

    suspend fun testConnection(
        rtdbUrl: String,
        uid: String,
        trackerId: String
    ): Result<Long> {
        val validUrl = validateRtdbUrl(rtdbUrl)
            ?: return Result.failure(IllegalArgumentException("Enter a valid https:// Firebase Realtime Database URL."))

        val startMs = System.currentTimeMillis()
        return try {
            withTimeout(8_000L) {
                val database = FirebaseDatabase.getInstance(validUrl)
                val testRef = database.getReference("live_trackers")
                    .child(uid)
                    .child(trackerId)
                    .child("connection_test")

                testRef.setValue(
                    mapOf(
                        "uid" to uid,
                        "trackerId" to trackerId,
                        "status" to "OK",
                        "testedAt" to ServerValue.TIMESTAMP
                    )
                ).await()
            }
            val latencyMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
            Result.success(latencyMs)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(Exception(mapFriendlyRtdbError(e), e))
        }
    }

    private fun mapFriendlyRtdbError(e: Exception): String {
        val msg = e.message.orEmpty()
        return when {
            msg.contains("Permission denied", ignoreCase = true) ->
                "Permission denied by Realtime Database rules. Copy and paste the updated RTDB rules from Setup in Firebase Console."
            msg.contains("timed out", ignoreCase = true) || msg.contains("Timeout", ignoreCase = true) ->
                "Timed out connecting to Realtime Database. Verify RTDB is created in Firebase Console and the URL is exact."
            else -> msg.ifBlank { "Failed to emit coordinate to Firebase Realtime Database." }
        }
    }
}
