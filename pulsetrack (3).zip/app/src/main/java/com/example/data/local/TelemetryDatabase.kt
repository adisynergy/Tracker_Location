package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.SyncStatus
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "telemetry_points")
data class TelemetryPointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val userId: String,
    val trackerId: String,
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val altitudeMeters: Double,
    val speedMps: Float,
    val bearingDegrees: Float,
    val provider: String,
    val recordedAtMs: Long,
    val syncStatus: String = SyncStatus.PENDING.name,
    val syncMessage: String = ""
)

@Dao
interface TelemetryDao {
    @Query("SELECT * FROM telemetry_points WHERE userId = :userId ORDER BY recordedAtMs DESC LIMIT :limit")
    fun observeRecentPoints(userId: String, limit: Int = 100): Flow<List<TelemetryPointEntity>>

    @Query("SELECT COUNT(*) FROM telemetry_points WHERE userId = :userId AND syncStatus != 'SYNCED'")
    fun observePendingCount(userId: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM telemetry_points WHERE userId = :userId AND syncStatus = 'SYNCED'")
    fun observeSyncedCount(userId: String): Flow<Int>

    @Query("SELECT * FROM telemetry_points WHERE userId = :userId AND syncStatus != 'SYNCED' ORDER BY recordedAtMs ASC LIMIT :limit")
    suspend fun getPendingPoints(userId: String, limit: Int = 25): List<TelemetryPointEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPoint(point: TelemetryPointEntity): Long

    @Query("UPDATE telemetry_points SET syncStatus = 'SYNCED', syncMessage = :message WHERE id = :id")
    suspend fun markSynced(id: Long, message: String = "Emitted")

    @Query("UPDATE telemetry_points SET syncStatus = 'FAILED', syncMessage = :message WHERE id = :id")
    suspend fun markFailed(id: Long, message: String)

    @Query("DELETE FROM telemetry_points WHERE userId = :userId")
    suspend fun clearUserPoints(userId: String)
}

@Database(entities = [TelemetryPointEntity::class], version = 1, exportSchema = false)
abstract class TelemetryDatabase : RoomDatabase() {
    abstract fun telemetryDao(): TelemetryDao

    companion object {
        @Volatile
        private var INSTANCE: TelemetryDatabase? = null

        fun getInstance(context: Context): TelemetryDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    TelemetryDatabase::class.java,
                    "pulsetrack_telemetry.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
